const products = [
  {
    id: 1,
    name: "ساعت هوشمند",
    category: "electronics",
    price: 1850000,
    description: "ساعت هوشمند مارک اپل با بهترین کیفیت روز.",
    image: "pics/template-1.png"
  },
  {
    id: 2,
    name: "Redmi note 14pro plus 5g",
    category: "electronics",
    price: 32000000,
    description: "گوشی Xiaomi redmi note 14pro plus 5g حافظه 256gb و رم 8gb.",
    image: "pics/template-3.png"
  },
  {
    id: 3,
    name: "لیپ گلاس کیکو",
    category: "fashion",
    price: 980000,
    description: "ماندگاری بالا و قابل استفاده در فصل تابستان.",
    image: "pics/template-1.png"
  },
  {
    id: 4,
    name: "گریپستر",
    category: "sports",
    price: 2450000,
    description: "گریپستر برای بالا رفتن قدرت دست و بیرون زدن رگ های دست.",
    image: "pics/template-2.png"
  },
  {
    id: 5,
    name: "قهوه ساز",
    category: "home",
    price: 670000,
    description: "قهوه ساز مارک ninja با بهترین کیفیت روز.",
    image: "pics/template-3.png"
  }
];

const categories = {
  electronics: { label: "الکترونیک", icon: "fa-mobile-screen" },
  fashion: { label: "آرایشی", icon: "fa-spray-can-sparkles" },
  home: { label: "لوازم جانبی", icon: "fa-mug-hot" },
  sports: { label: "اسپرت", icon: "fa-dumbbell" }
};

let cart = [];
try {
  cart = JSON.parse(localStorage.getItem("shopx-cart")) || [];
} catch (e) {
  cart = [];
}

function saveCart() {
  localStorage.setItem("shopx-cart", JSON.stringify(cart));
}

function formatPrice(price) {
  return price.toLocaleString("fa-IR") + " تومان";
}

function getCategoryLabel(category) {
  return categories[category] ? categories[category].label : category;
}

function getCategoryIcon(category) {
  return categories[category] ? categories[category].icon : "fa-tag";
}

/* ---------- Toast (جایگزین alert) ---------- */
function showToast(message, type = "success") {
  const wrap = document.getElementById("toastWrap");
  const toast = document.createElement("div");
  toast.className = "toast " + type;
  const icon = type === "success" ? "fa-circle-check" : "fa-circle-info";
  toast.innerHTML = `<i class="fa-solid ${icon}"></i><span>${message}</span>`;
  wrap.appendChild(toast);

  setTimeout(() => {
    toast.classList.add("hide");
    setTimeout(() => toast.remove(), 300);
  }, 2200);
}

/* ---------- Products ---------- */
function renderProducts() {
  const grid = document.getElementById("productsGrid");
  const searchInput = document.getElementById("searchInput");
  const search = searchInput.value.trim().toLowerCase();
  const category = document.getElementById("categoryFilter").value;

  document.getElementById("searchClear").hidden = search === "";

  const filtered = products.filter(product => {
    const matchSearch =
      product.name.toLowerCase().includes(search) ||
      product.description.toLowerCase().includes(search);
    const matchCategory = category === "all" || product.category === category;
    return matchSearch && matchCategory;
  });

  document.getElementById("productCount").textContent =
    `${filtered.length.toLocaleString("fa-IR")} محصول یافت شد`;

  if (filtered.length === 0) {
    grid.innerHTML = `
      <div class="empty-state">
        <i class="fa-regular fa-face-frown-open"></i>
        <p>محصولی پیدا نشد.</p>
        <small>یه چیز دیگه جست‌وجو کن یا دسته رو عوض کن.</small>
      </div>`;
    return;
  }

  grid.innerHTML = filtered.map(product => `
    <div class="product">
      <img src="${product.image}" alt="${product.name}" loading="lazy">
      <div class="product-content">
        <span class="badge"><i class="fa-solid ${getCategoryIcon(product.category)}"></i> ${getCategoryLabel(product.category)}</span>
        <h3>${product.name}</h3>
        <p>${product.description}</p>
        <div class="price-row">
          <span class="price">${formatPrice(product.price)}</span>
          <button class="add-cart" onclick="addToCart(${product.id})">
            <i class="fa-solid fa-cart-plus"></i> افزودن
          </button>
        </div>
      </div>
    </div>
  `).join("");
}

function clearSearch() {
  const input = document.getElementById("searchInput");
  input.value = "";
  input.focus();
  renderProducts();
}

/* ---------- Cart ---------- */
function addToCart(id) {
  const product = products.find(p => p.id === id);
  const existing = cart.find(item => item.id === id);

  if (existing) {
    existing.qty += 1;
  } else {
    cart.push({ ...product, qty: 1 });
  }

  saveCart();
  renderCart();
  showToast(`${product.name} به سبد خرید اضافه شد.`);
}

function changeQty(id, delta) {
  const item = cart.find(item => item.id === id);
  if (!item) return;

  item.qty += delta;

  if (item.qty <= 0) {
    cart = cart.filter(item => item.id !== id);
  }

  saveCart();
  renderCart();
}

function removeItem(id) {
  cart = cart.filter(item => item.id !== id);
  saveCart();
  renderCart();
  showToast("محصول از سبد حذف شد.", "info");
}

function clearCart() {
  if (cart.length === 0) return;
  cart = [];
  saveCart();
  renderCart();
  showToast("سبد خرید خالی شد.", "info");
}

function renderCart() {
  const cartBox = document.getElementById("cartItems");
  const count = cart.reduce((sum, item) => sum + item.qty, 0);
  document.getElementById("cartCount").textContent = count.toLocaleString("fa-IR");
  document.getElementById("cartCount").classList.toggle("visible", count > 0);

  if (cart.length === 0) {
    cartBox.innerHTML = `
      <div class="empty-state">
        <i class="fa-solid fa-cart-shopping"></i>
        <p>سبد خرید خالی است.</p>
        <small>از بخش محصولات چیزی اضافه کن.</small>
      </div>`;
    document.getElementById("cartTotal").textContent = "مجموع: 0 تومان";
    return;
  }

  let total = 0;

  cartBox.innerHTML = cart.map(item => {
    total += item.price * item.qty;
    return `
      <div class="cart-item">
        <div class="cart-info">
          <img class="cart-thumb" src="${item.image}" alt="${item.name}">
          <div>
            <h4>${item.name}</h4>
            <small>${formatPrice(item.price)} × ${item.qty.toLocaleString("fa-IR")}</small><br>
            <small><i class="fa-solid ${getCategoryIcon(item.category)}"></i> ${getCategoryLabel(item.category)}</small>
          </div>
        </div>
        <div class="qty-controls">
          <button onclick="changeQty(${item.id}, -1)" aria-label="کم کردن"><i class="fa-solid fa-minus"></i></button>
          <span>${item.qty.toLocaleString("fa-IR")}</span>
          <button onclick="changeQty(${item.id}, 1)" aria-label="زیاد کردن"><i class="fa-solid fa-plus"></i></button>
          <button class="remove-btn" onclick="removeItem(${item.id})" title="حذف" aria-label="حذف"><i class="fa-solid fa-trash-can"></i></button>
        </div>
      </div>
    `;
  }).join("");

  document.getElementById("cartTotal").textContent = `مجموع: ${formatPrice(total)}`;
}

/* ---------- Menu & scroll ---------- */
function toggleMenu() {
  document.getElementById("mobileMenu").classList.toggle("open");
}

function scrollToSection(id) {
  document.getElementById(id).scrollIntoView({ behavior: "smooth" });
}

/* ---------- Custom dropdown ---------- */
function initDropdown() {
  const dropdown = document.getElementById("categoryDropdown");
  const toggle = dropdown.querySelector(".dropdown-toggle");
  const menu = dropdown.querySelector(".dropdown-menu");
  const items = Array.from(menu.querySelectorAll("li"));
  const hidden = document.getElementById("categoryFilter");
  const label = document.getElementById("categoryLabel");
  const icon = document.getElementById("categoryIcon");

  function open() {
    dropdown.classList.add("open");
    toggle.setAttribute("aria-expanded", "true");
  }

  function close() {
    dropdown.classList.remove("open");
    toggle.setAttribute("aria-expanded", "false");
    items.forEach(li => li.classList.remove("active"));
  }

  function select(li) {
    items.forEach(i => {
      i.classList.remove("selected");
      i.setAttribute("aria-selected", "false");
    });
    li.classList.add("selected");
    li.setAttribute("aria-selected", "true");

    hidden.value = li.dataset.value;
    label.textContent = li.textContent.trim();
    icon.className = "fa-solid " + li.dataset.icon;

    close();
    renderProducts();
  }

  toggle.addEventListener("click", () => {
    dropdown.classList.contains("open") ? close() : open();
  });

  items.forEach(li => {
    li.setAttribute("tabindex", "-1");
    li.addEventListener("click", () => select(li));
  });

  // کلیک بیرون = بستن
  document.addEventListener("click", e => {
    if (!dropdown.contains(e.target)) close();
  });

  // کیبورد
  dropdown.addEventListener("keydown", e => {
    const isOpen = dropdown.classList.contains("open");
    let current = items.findIndex(li => li.classList.contains("active"));
    if (current === -1) current = items.findIndex(li => li.classList.contains("selected"));

    if (e.key === "Escape") {
      close();
      toggle.focus();
    } else if (e.key === "ArrowDown" || e.key === "ArrowUp") {
      e.preventDefault();
      if (!isOpen) return open();
      const next = e.key === "ArrowDown"
        ? (current + 1) % items.length
        : (current - 1 + items.length) % items.length;
      items.forEach(li => li.classList.remove("active"));
      items[next].classList.add("active");
      items[next].scrollIntoView({ block: "nearest" });
    } else if (e.key === "Enter" && isOpen) {
      const active = items.find(li => li.classList.contains("active"));
      if (active) {
        e.preventDefault();
        select(active);
        toggle.focus();
      }
    }
  });
}

initDropdown();
renderProducts();
renderCart();
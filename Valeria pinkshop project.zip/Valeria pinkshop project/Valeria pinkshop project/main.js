    const products = [
      {
        id: 1,
        name: "ساعت هوشمند",
        category: "electronics",
        price: 1850000,
        description: "ساعت هوشمند مارک اپل با بهترین کیفیت روز.",
        image: "pics/template-1.png"
      },
      {
        id: 2,
        name: "Redmi note 14pro plus 5g",
        category: "electronics",
        price: 32000000,
        description: "گوشی Xiaomi redmi note 14pro plus 5g حافظه 256gb و رم 8gb.",
        image: "pics/template-3.png"
      },
      {
        id: 3,
        name: "لیپ گلاس کیکو",
        category: "fashion",
        price: 980000,
        description: "ماندگاری بالا و قابل استفاده در فصل تابستان.",
        image: "pics/template-1.png"
      },
      {
        id: 4,
        name: "گریپستر",
        category: "sports",
        price: 2450000,
        description: "گریپستر برای بالا رفتن قدرت دست و بیرون زدن رگ های دست.",
        image: "pics/template-2.png"
      },
      {
        id: 5,
        name: "قهوه ساز",
        category: "home",
        price: 670000,
        description: "قهوه ساز مارک ninja با بهترین کیفیت روز.",
        image: "pics/template-3.png"
      }
    ];

    let cart = JSON.parse(localStorage.getItem("shopx-cart")) || [];

    function saveCart() {
      localStorage.setItem("shopx-cart", JSON.stringify(cart));
    }

    function formatPrice(price) {
      return price.toLocaleString("fa-IR") + " تومان";
    }

    function renderProducts() {
      const grid = document.getElementById("productsGrid");
      const search = document.getElementById("searchInput").value.toLowerCase();
      const category = document.getElementById("categoryFilter").value;

      const filtered = products.filter(product => {
        const matchSearch =
          product.name.toLowerCase().includes(search) ||
          product.description.toLowerCase().includes(search);

        const matchCategory = category === "all" || product.category === category;

        return matchSearch && matchCategory;
      });

      document.getElementById("productCount").textContent = `${filtered.length} محصول یافت شد`;

      grid.innerHTML = filtered.map(product => `
        <div class="product">
          <img src="${product.image}" alt="${product.name}">
          <div class="product-content">
            <span class="badge">${getCategoryLabel(product.category)}</span>
            <h3>${product.name}</h3>
            <p>${product.description}</p>
            <div class="price-row">
              <span class="price">${formatPrice(product.price)}</span>
              <button class="add-cart" onclick="addToCart(${product.id})">افزودن</button>
            </div>
          </div>
        </div>
      `).join("");

      if (filtered.length === 0) {
        grid.innerHTML = `<p style="grid-column:1/-1; text-align:center; color:#6b7280;">محصولی پیدا نشد.</p>`;
      }
    }

    function getCategoryLabel(category) {
      const labels = {
        electronics: "الکترونیک",
        fashion: "آرایشی",
        home: "لوازم جانبی",
        sports: "اسپرت"
      };
      return labels[category] || category;
    }

    function addToCart(id) {
      const product = products.find(p => p.id === id);
      const existing = cart.find(item => item.id === id);

      if (existing) {
        existing.qty += 1;
      } else {
        cart.push({ ...product, qty: 1 });
      }

      saveCart();
      renderCart();
      alert(`${product.name} به سبد خرید اضافه شد.`);
    }

    function changeQty(id, delta) {
      const item = cart.find(item => item.id === id);
      if (!item) return;

      item.qty += delta;

      if (item.qty <= 0) {
        cart = cart.filter(item => item.id !== id);
      }

      saveCart();
      renderCart();
    }

    function removeItem(id) {
      cart = cart.filter(item => item.id !== id);
      saveCart();
      renderCart();
    }

    function clearCart() {
      cart = [];
      saveCart();
      renderCart();
    }

    function renderCart() {
      const cartBox = document.getElementById("cartItems");

      if (cart.length === 0) {
        cartBox.innerHTML = `<p style="color:#6b7280; text-align:center; padding:18px 0;">سبد خرید خالی است.</p>`;
        document.getElementById("cartTotal").textContent = "مجموع: 0 تومان";
        return;
      }

      let total = 0;

      cartBox.innerHTML = cart.map(item => {
        total += item.price * item.qty;
        return `
          <div class="cart-item">
            <div>
              <h4>${item.name}</h4>
              <small>${formatPrice(item.price)} × ${item.qty}</small><br>
              <small>${getCategoryLabel(item.category)}</small>
            </div>
            <div class="qty-controls">
              <button onclick="changeQty(${item.id}, -1)">-</button>
              <span>${item.qty}</span>
              <button onclick="changeQty(${item.id}, 1)">+</button>
              <button onclick="removeItem(${item.id})" title="حذف">🗑️</button>
            </div>
          </div>
        `;
      }).join("");

      document.getElementById("cartTotal").textContent = `مجموع: ${formatPrice(total)}`;
    }

    function toggleMenu() {
      document.getElementById("mobileMenu").classList.toggle("open");
    }

    function scrollToSection(id) {
      document.getElementById(id).scrollIntoView({ behavior: "smooth" });
    }

    renderProducts();
    renderCart();